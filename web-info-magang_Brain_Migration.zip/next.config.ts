import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // We keep this empty to satisfy TypeScript.
  // This ensures no conflicting "middleware" settings exist.
};

export default nextConfig;